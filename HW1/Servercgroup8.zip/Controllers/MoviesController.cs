﻿using Microsoft.AspNetCore.Mvc;
using HW1.BL;
using HW1.DAL;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HW1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<Movies> Get()
        {
            return null;
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }


        // POST api/<MoviesController>
        [HttpPost]
        public IActionResult Post([FromBody] Movies movie)
        {
            if (movie.InsertMovie())
            {
                return Ok(new { message = "Movie inserted successfully." });
            }

            return Conflict("❌ Failed to insert movie.");
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Movies movie)
        {
            if (movie.UpdateMovie(id))
                return Ok(new { message = "Movie updated successfully." });

            return NotFound(new { message = "Movie not found." });
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            if (new Movies().DeleteMovie(id))
                return Ok(new { message = "Movie deleted successfully." });

            return NotFound(new { message = "Movie not found." });
        }

        // POST api/Movies/batch
        [HttpPost("batch")]
        public IActionResult InsertMoviesBatch([FromBody] List<Movies> moviesList)
        {
            if (moviesList == null || moviesList.Count == 0)
                return BadRequest("No movies provided.");
            Movies movie = new Movies();
            
            int successCount = movie.InsertMoviesList(moviesList);
            return Ok(new { message = $"{successCount} movies inserted successfully." });
        }

        // POST api/Movies/rent

        [HttpPost("rent")]
        public IActionResult RentMovie([FromBody] RentRequest rentRequest)
        {
           
            bool success = new Movies().RentMovie(rentRequest);

            if (success)
                return Ok(new { message = "Movie rented successfully!" });

            return BadRequest(new { message = "❌ Failed to rent movie." });
        }


        //[HttpGet("getByTitle")] // this uses the QueryString
        //public IEnumerable<Movies> GetByTitle(string title)
        //{
        //    Movies movie = new Movies();
        //    return movie.GetByTitle(title);

        //}


        //[HttpGet("from/{startDate}/until/{endDate}")] // this uses resource routing
        //public IEnumerable<Movies> GetByReleaseDate(DateTime startDate, DateTime endDate)
        //{
        //    Movies movie = new Movies();
        //    return movie.GetByReleaseDate(startDate,endDate);

        //}

    }
}
